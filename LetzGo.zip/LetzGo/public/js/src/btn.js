// btn waves
	Waves.displayEffect({
		duration: 900
	});
// footer push
	function footerPush() {
		$('body').css('margin-bottom', $('.footer').outerHeight());
	}